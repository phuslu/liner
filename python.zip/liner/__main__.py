import liner
getattr(liner, next(x for x in dir(liner) if x[0] != '_'))()
